//go:build !windows

package locafero

const globMatch = "*?[]\\^"
