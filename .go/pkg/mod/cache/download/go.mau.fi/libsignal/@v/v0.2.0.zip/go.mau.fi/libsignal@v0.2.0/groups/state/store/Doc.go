// Package store provides the storage interfaces for storing group sender
// key records.
package store
