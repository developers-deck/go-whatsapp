// Package fingerprint provides a way to generate a visually verifiable
// fingerprint of keys.
package fingerprint
