# go.mau.fi/util
This repository contains various Go utilities used by mautrix-go, bridges
written in Go, as well as some other related libraries like whatsmeow.
