INSERT INTO foo VALUES ('meow 2', '{}');
