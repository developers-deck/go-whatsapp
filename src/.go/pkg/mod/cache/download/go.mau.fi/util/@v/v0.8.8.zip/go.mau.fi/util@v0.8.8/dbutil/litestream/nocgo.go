//go:build !cgo

package litestream
