package instamadilloDeleteMessage

func (*DeleteMessagePayload) IsMessageApplicationSub() {}
