package waCommon

// Deprecated: Use GetID
func (x *MessageKey) GetId() string {
	return x.GetID()
}

// Deprecated: Use GetRemoteJID
func (x *MessageKey) GetRemoteJid() string {
	return x.GetRemoteJID()
}
