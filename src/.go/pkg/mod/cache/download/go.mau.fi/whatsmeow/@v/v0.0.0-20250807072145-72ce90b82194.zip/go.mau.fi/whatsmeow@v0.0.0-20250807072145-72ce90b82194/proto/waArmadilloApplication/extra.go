package waArmadilloApplication

func (*Armadillo) IsMessageApplicationSub() {}
