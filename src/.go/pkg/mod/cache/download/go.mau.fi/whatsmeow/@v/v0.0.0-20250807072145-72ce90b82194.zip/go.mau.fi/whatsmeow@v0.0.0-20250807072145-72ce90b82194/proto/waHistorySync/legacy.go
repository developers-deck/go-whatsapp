package waHistorySync

// Deprecated: Use GetID
func (x *Conversation) GetId() string {
	return x.GetID()
}

// Deprecated: Use GetID
func (x *Pushname) GetId() string {
	return x.GetID()
}
