package instamadilloAddMessage

func (*AddMessagePayload) IsMessageApplicationSub() {}
