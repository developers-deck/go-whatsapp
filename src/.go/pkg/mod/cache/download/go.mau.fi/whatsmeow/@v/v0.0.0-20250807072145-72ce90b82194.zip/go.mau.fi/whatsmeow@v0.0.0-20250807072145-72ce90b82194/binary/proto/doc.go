// Package proto contains type aliases for backwards compatibility.
//
// Deprecated: New code should reference the protobuf types in the go.mau.fi/whatsmeow/proto/wa* packages directly.
package proto
