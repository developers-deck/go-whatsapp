# goid ![Build Status](https://github.com/petermattis/goid/actions/workflows/go.yml/badge.svg)

Programatically retrieve the current goroutine's ID. See [the CI
configuration](.github/workflows/go.yml) for supported Go versions.
