# Security Policy

Thank you for helping us improve the security of the project. Your contributions are greatly appreciated.

## Reporting a Vulnerability

If you discover a security vulnerability within this project, please email the maintainers at [contact@mark3labs.com](mailto:contact@mark3labs.com).
