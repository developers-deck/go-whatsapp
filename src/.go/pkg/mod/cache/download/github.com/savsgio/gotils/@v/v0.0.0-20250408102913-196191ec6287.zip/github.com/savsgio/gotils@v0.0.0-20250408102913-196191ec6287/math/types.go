package math

// Float64Calculator is a calculator for float64 values.
type Float64Calculator struct{}
